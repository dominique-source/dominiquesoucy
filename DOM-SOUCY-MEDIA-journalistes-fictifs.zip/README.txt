DOM SOUCY MEDIA — Portraits de personnages fictifs générés par IA.
Décompressez le ZIP, importez les huit PNG dans le Studio.
Ne jamais présenter ces personnages comme de vrais journalistes.
marie-eve-gagnon.png — Marie-Ève Gagnon / Société / Éducation
julie-martin.png — Julie Martin / Société
marc-tremblay.png — Marc Tremblay / Économie
anne-richard.png — Anne Richard / Éducation
sofia-mendes.png — Sofia Mendes / Culture
malik-laurent.png — Malik Laurent / Sport et performance
naomi-diallo.png — Naomi Diallo / Jeunesse
alex-nguyen.png — Alex Nguyen / Innovation