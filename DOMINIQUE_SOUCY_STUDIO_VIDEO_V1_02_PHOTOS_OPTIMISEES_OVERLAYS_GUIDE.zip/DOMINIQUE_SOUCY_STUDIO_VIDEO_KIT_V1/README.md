# DOMINIQUE SOUCY — STUDIO VIDÉO & CONTENU — KIT V1

## CONTENU
- `01_PHOTOS_ORIGINALES/` : **29 fichiers reçus** ; certains sont des copies répétées. Aucune retouche de visage.
- `02_PHOTOS_OPTIMISEES/` : variantes WebP pour 16:9 / 9:16 / 1:1, recadrées automatiquement ; **vérifier chaque cadrage** dans l'application, particulièrement les mains et le visage.
- `03_MAQUETTES/VIDEO_STUDIO/` : maquettes de l'app de production, overlays broadcast, timeline, IA et exportation ; **concepts raster non éditables**, chiffres et médias illustratifs non réels.
- `03_MAQUETTES/REFERENCES_SITE_COMPLEMENTAIRES/` : autres maquettes du site apparues sous les numéros 10–18 ; **elles ne représentent pas les spécifications fonctionnelles du studio vidéo**.
- `04_OVERLAYS_SVG/` : 15 fichiers vectoriels **éditables** et fonds transparents, gabarits texte destinés à être reconstruits comme composants animables. Ne jamais intégrer le texte placeholder en production.
- `05_DESIGN_SYSTEM/` : tokens CSS/JSON, storyboard d'animation, catalogue photo avec SHA256.
- `06_GUIDE_CODEX/` : brief, prompt et livrables.
- `07_PREVISUALISATIONS/` : planche-contact des photographies.

## NOTES IMPORTANTES
Les 18 numéros de maquette de la conversation ne correspondent PAS tous aux 18 écrans de postproduction initialement projetés : les maquettes 10–18 ont évolué vers des pages du site public. Le ZIP les conserve comme références complémentaires, mais le produit **Studio Vidéo & Contenu** doit être spécifié indépendamment.

Les photos du jardin sont de vraies photos fournies par Dominique, pas des captures d'une vraie conférence de presse. Ne pas présenter les maquettes IA comme de vrais enregistrements. Les visages des journalistes illustratifs sont fictifs et ne doivent pas être présentés comme vrais journalistes ni personnes identifiables.

Aucun fichier vidéo source n'a été fourni, donc il n'y a **pas d'animations prérendues ni de vidéos finales** dans le ZIP. Le moteur d'édition doit produire ces rendus depuis les médias et les données réels.

Les SVG sont des assets techniques de démarrage. Ne jamais exposer de secret d'API ni de mot de passe dans le frontend.
