# INTÉGRATION
1. Décompresser dans dossier de travail temporaire, **ne pas mettre les 29 photos originales dans le repo public automatiquement**. Importer les médias privés via stockage objet quand disponible.
2. Utiliser `01_PHOTOS_ORIGINALES` comme master. `02_PHOTOS_OPTIMISEES` comme aperçu; recadrer individuellement pour conserver les mains.
3. Utiliser `03_MAQUETTES/VIDEO_STUDIO` pour reproduire le design des interfaces, PAS pour simuler un produit terminé.
4. Charger `05_DESIGN_SYSTEM/tokens.css` et créer des composants React/Canvas/Remotion ou autre rendu déterministe selon le choix d'architecture.
5. Adapter `04_OVERLAYS_SVG` pour chaque ratio: placeholders texte à remplacer par contenu réel de transcription/questions.
6. Aucun rush vidéo, piste OBS ni question enregistrée n'est fourni dans ce kit; tester avec des sources de démonstration clairement identifiées.
7. Voir `PROMPT_CODEX_V8.md`.
