# CODEX — REFONTE GRAPHIQUE ACCUEIL DOMINIQUESOUCY.COM 9,8 — V1

Dépôt : `dominique-source/dominiquesoucy`.

Tu as accès au ZIP `DOMINIQUE_SOUCY_ACCUEIL_98_MAQUETTES_V1.zip` et ses quatre maquettes, aux photographies originales et au guide. Inspecte `AGENTS.md`, les routes, composants, styles et tests actuels avant toute intervention.

## MISSION
Construire un accueil premium, authentique, optimisé pour mobile et ordinateur, en s’inspirant de la composition des quatre maquettes sans utiliser les rendus IA comme véritables photographies de Dominique. Réutiliser les originaux du dépôt et ceux du dossier `02_PHOTOS_REELLES_REFERENCE`. **Ne pas régénérer son visage**.

## STRUCTURE ÉDITORIALE
1. Header fixe ou discret : logo, Réflexions, Épisodes / pilote, La conversation / Boîte à questions (seulement si réellement disponible), Le parcours, FR/EN. Accès au studio privé discret, protégé par serveur.
2. Hero percutant : photo réelle en grand, « Le sport comme miroir de la société. », sous-titre « Faire réfléchir avant de faire réagir. », CTA réel « Regarder le pilote », CTA secondaire vers les réflexions. Pour mobile, visage non masqué, titre lisible et première action avant trop de défilement.
3. Un SEUL pilote en vedette, avec le lecteur existant, véritable poster et lien validé. Ne pas inventer une deuxième émission. Réduire l’effet de répétition.
4. Trois portes éditoriales distinctes : Réflexions; La conversation / Questions (seulement si fonction disponible, sinon accès explicite vers contact ou mention à venir); Le parcours. Utiliser vrais médias et contenus disponibles.
5. Une section claire, lumineuse et respirante sur l’implication communautaire. Appel à participer non trompeur.
6. Une section de parcours concise et biographiquement exacte, puis pied de page propre, liens fonctionnels.

## DESIGN
- Utiliser `#0A0A0A`, `#F4F4EF`, `#CCFF00` de manière cohérente.
- Typo display Barlow Condensed bold italique; texte Inter.
- Prioriser contraste, grilles et espaces vides; réserver lime aux actions et accents significatifs.
- Alternance de sections sombres et off-white; transitions sobres, fondus et scroll animation légère uniquement là où cela apporte une information.
- Ne pas reproduire de fausses citations, durées, statistiques, films, photos d’enfance ou noms de personnes visibles dans des concepts générés.
- Les maquettes sont des visuels de composition, pas des sources factuelles.

## TECHNIQUE
- Préserver les systèmes existants, notamment `/fr/studio-live`, ses endpoints et sa sécurité.
- Vérifier les chemins des médias réels; Next Image pour les photos.
- Accessibilité clavier, contraste suffisant, titres sémantiques, focus, `prefers-reduced-motion`, responsive 390/768/1440/1920.
- Aucun lien mort, aucun CTA simulé comme une fonctionnalité prête.
- Ne pas afficher le formulaire Boîte à questions avant d'avoir un stockage réel et une gestion claire du consentement.
- Optimiser CLS/LCP et poids des photographies. Ne pas embarquer les maquettes PNG de plusieurs Mo dans la page rendue.
- Rédiger tests et captures de contrôle sur desktop/mobile; exécuter lint, typecheck, tests et build quand disponibles.

## LIVRAISON
- Créer branche `codex/homepage-editorial-98-v1`, PR à valider, sans fusionner ni déployer automatiquement.
- Fournir captures 390px et 1440px, inventaire des photos retenues, avant/après, problèmes non résolus et résultat des tests.
- Ne pas toucher aux contenus publics au-delà de ce qui est nécessaire à la composition validée.
