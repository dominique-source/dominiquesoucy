# DOMINIQUE SOUCY — ACCUEIL 9,8 · KIT DE MAQUETTES V1

## Contenu
Quatre maquettes de **direction artistique**, une planche-contact et quatre photographies originales fournies par Dominique, à titre de référence d’identité.

- `01_HERO_CONVERSATION_DESKTOP.png` : accroche, portrait, appel à participer et carte vidéo.
- `02_REFLEXIONS_BOITE_QUESTIONS.png` : grille éditoriale et section participative contrastée.
- `03_ACCUEIL_COMPLET_DIRECTION_A.png` : proposition de défilement et navigation, sections et pied de page.
- `04_ACCUEIL_COMPLET_DIRECTION_B.png` : proposition alternative plus minimaliste, avec carte principale, trois entrées et invitation finale.

**ATTENTION : les maquettes sont des rendus conceptuels, pas des captures du site.** Les visages peuvent avoir été réinterprétés par le générateur d’images : **ne pas les utiliser comme photos biographiques réelles sur le site final**. Utiliser les JPEG originaux fournis ici ou les véritables médias du repo. Les maquettes contiennent des titres de publications, durées, citations et interfaces fictifs : ne pas les publier tels quels. Réutiliser la composition et les codes graphiques, mais uniquement le contenu vérifié du dépôt ou validé par Dominique.

## Direction recommandée
- Base : la mise en page de `04_ACCUEIL_COMPLET_DIRECTION_B`, mais avec la structure d’exploration du `03`.
- Une seule vidéo pilote en vedette, et jamais trois vignettes du même pilote présentées comme trois contenus différents.
- Enchaînement : hero → pilote → 3 portes d’entrée → participation → parcours condensé → pied de page.
- Faire respirer l’interface entre les zones fortes; privilégier le rythme et la sobriété.
- Palette historique du site : noir `#0A0A0A`, blanc cassé `#F4F4EF`, lime `#CCFF00`. (Les maquettes peuvent afficher un vert approximatif.)
- Garder le portrait réel fidèle, sans génération de nouveau visage et sans altération d’identité.
- Les espaces privés (studio live et montage) restent protégés; les appeler discrètement depuis la navigation.
- Ne pas présenter une Boîte à questions non fonctionnelle comme un service ouvert au public.
- Prévoir FR / EN, mobile 390px, tablette 768px, desktop 1440px, accessibilité WCAG, respect reduced-motion.

## Mode opératoire Codex
Voir `03_GUIDE_CODEX/PROMPT_CODEX_ACCUEIL_98_V1.md`.
