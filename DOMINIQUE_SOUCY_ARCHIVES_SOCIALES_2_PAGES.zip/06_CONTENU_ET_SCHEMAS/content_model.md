# Schéma proposé
ArchivePost: id, slug, locale, status(draft/published), type(post/reel), exactOriginalText, editorialTitle, deck, editorialTags[], sourceUrl, originalPublishedAt(nullable), heroAssetId(nullable), publishedAt(nullable), discussionThreadId, createdAt, updatedAt.
Asset: id, storageKey, owner, contentType, width/height, alt, originalFileName, sourceUrl(nullable), licence/consent metadata, variants, createdAt.
Thread: id, archivePostId, public, questionIds[], createdAt.
Question: id, threadId, kind(text/audio/video), body, mediaId, submittedAt, displayName, reactions; same underlying community app backend when feasible.
Backoffice: authenticated admin role, media upload tokens, post drafts, selection for show; no shared hardcoded password in client.
Do not assume a direct relationship between the eight original Facebook URLs and the screenshot until Dominique confirms it.
