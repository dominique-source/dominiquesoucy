# Design system — Archives sociales
- Palette: noir #0A0A0A, blanc cassé #F4F4EF, lime #CCFF00; fonds de cartes #151515.
- Typographie: utiliser prioritairement les polices et composants réellement installés dans le dépôt; titres très condensés gras italique si déjà disponibles, texte courant lisible.
- Desktop archives: portrait authentique à gauche, regard dirigé à droite; grille de cartes à droite.
- Desktop article: article à gauche, module de discussion à droite. Mobile: une seule colonne.
- Ne pas découper les maquettes en blocs d'UI; reconstruire en React accessible.
- Pas de fausses métriques, personnes, réactions ni commentaires provenant des maquettes.
- Les cartes Facebook et Reels doivent afficher de vraies miniatures autorisées, ou un placeholder neutre sans prétendre montrer le contenu.
