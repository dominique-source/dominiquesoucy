# Kit d'intégration — Archives sociales
## Livrables
01_MAQUETTES : deux maquettes d'orientation visuelle; les miniatures, chiffres et commentaires sont conceptuels.
02_PHOTOS_AUTHENTIQUES : portrait IMG_6234 fourni dans la conversation; copies web.
03_SOURCES_FACEBOOK : capture écran transmise de « Commençons donc par la base », preuve de texte / contexte; **PAS la photo originale de la publication**.
04_SVG : icônes et accent lime. SVG utilisent currentColor (sauf lime underline).
05_DESIGN_SYSTEM : tokens et notes d'accessibilité.
06_CONTENU_ET_SCHEMAS : texte de publication, 8 liens fournis et modèle de données.
07_GUIDE_CODEX : ce guide et prompt d'implémentation.

## Priorités
1. Ne pas inventer de médias Facebook, commentaires, réactions, dates précises ou statistiques.
2. Photo originale de la publication scolaire indisponible à ce stade: prévoir un emplacement et un upload mobile natif.
3. Le post n°1 de la liste Facebook n'a PAS été confirmé comme étant ce post scolaire; sourceUrl de celui-ci reste null dans le JSON.
4. Conserver le texte exact fourni, et séparer titre éditorial, extrait et propos de Dominique.
5. Protéger l'espace propriétaire; le public ne doit jamais avoir l'accès aux brouillons ni aux uploads.
6. Pour le mobile: bouton caméra/photo natif, prévisualisation, rotation EXIF, compression optionnelle, progression, validation des formats et taille, suppression/remplacement, descriptions alt.
7. Le fil public reste sans modération préalable selon décision utilisateur, avec signalement, retraits administratifs, anti-spam.
