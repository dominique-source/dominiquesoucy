# DOMINIQUE SOUCY — BOÎTE À QUESTIONS | Kit graphique V1

## Ce que contient ce ZIP

- `01_REFERENCES/` : deux maquettes approuvées/étapes conceptuelles. **Images de référence seulement : ne pas utiliser comme UI finale ni comme source de profils publics.**
- `02_PHOTOS_ORIGINALES/` : photo réelle fournie par Dominique dans la conversation, inchangée.
- `03_PHOTOS_WEB/` : trois recadrages et redimensionnements WebP de **la photo réelle**, sans changement du visage.
- `04_SVG_ICONS/` : 23 icônes vectorielles réutilisables et adaptables à la couleur CSS courante.
- `05_SVG_DECOR/` : graphismes lime, angles et arrière-plan neutre.
- `06_DESIGN_SYSTEM/` : couleurs, police, composants et CSS de départ.
- `07_GUIDE_CODEX/` : spécifications de mise en œuvre et notes de confidentialité.
- `08_DEMO_HTML/` : prototype HTML autonome à ouvrir dans un navigateur, pour visualiser la structure avec la vraie photo et des exemples *explicitement fictifs*.

## Direction artistique validée

- Photo vraie de Dominique **à gauche, regard dirigé vers la droite**.
- Fil de questions **à droite**, interface de type Twitter/X; texte / audio / vidéo.
- Navigation FR/EN, palette noire / blanc cassé / lime.
- Fil chronologique en temps réel, avec filtres par thème et format.
- **Pas de modération préalable pour cette V1, à la demande explicite de Dominique.** Prévoir toutefois signalement, suppression, anti-spam, limites de débit, sécurité des médias et masquage d'urgence.
- Questions publiques lisibles par tous. Formulaire public accessible sans mot de passe.
- Espace réservé à Dominique: tableau de bord, programmation, sélection et ordre des questions des émissions, masquage/suppression, contenus non publics, réglages de la conférence de presse.
- Code administrateur 151515 côté environnement privé seulement; ne pas le coder dans le dépôt public ni dans les fichiers livrés au navigateur. Ce code seul est faible; utiliser une session serveur et idéalement une authentification supplémentaire.

## Attention aux faux chiffres

Les captures conceptuelles contiennent des nombres tels que «128 en direct», «12 486 membres», des pseudos et des questions exemples. Ils sont **fictifs**. Ne jamais les présenter sur le site en production comme des faits. Afficher des compteurs uniquement calculés à partir de données réelles, et « aucune question » si la banque est vide. Le terme « EN DIRECT » ne doit être montré que si le système actualise réellement les publications.

## Architecture publique / privée recommandée

`/fr/questions` : fil public, recherche, tri nouveau/populaire, sujet, lecture audio/vidéo, soumission.
`/en/questions` : même expérience en anglais.
`/fr/studio-live/questions` : console privée avec liste et sélections pour l'émission.
`/fr/studio-live` : conférence de presse IA existante / à construire.

Une publication ne doit pas être modérée **avant** d'apparaître, mais le public doit savoir que sa question peut devenir visible immédiatement. Ajouter une confirmation explicite avant capture audio ou vidéo et des conditions claires sur la diffusion éventuelle dans une émission. Prévoir une limite de durée/taille et des règles raisonnables sur les données personnelles. Respecter les paramètres du navigateur pour la caméra et le micro.

## Mise en production

Le ZIP ne contient **pas** le backend, la base de données, le stockage des médias, ni l'API IA, qui doivent être implémentés. Le prototype est uniquement une démonstration graphique non connectée. 
